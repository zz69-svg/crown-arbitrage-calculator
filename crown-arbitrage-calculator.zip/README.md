# Crown Arbitrage Calculator

A simple tool for betting arbitrage calculation with rebates.